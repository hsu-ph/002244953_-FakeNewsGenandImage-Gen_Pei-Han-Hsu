# Modified version of generate_web_app.py for command-line usage
# This script accepts a prompt as a command-line argument and returns the path to the enhanced image

import os
import sys
import torch
import argparse
from PIL import Image
from diffusers import StableDiffusionPipeline
from realesrgan import RealESRGAN
from datetime import datetime

# Parse command-line arguments
parser = argparse.ArgumentParser(description="Generate and enhance an image from a text prompt")
parser.add_argument("--prompt", type=str, required=True, help="Text prompt for image generation")
args = parser.parse_args()

# === Path settings ===
PUBLIC_DIR = "public"
GENERATED_DIR = os.path.join(PUBLIC_DIR, "generated_images")
ENHANCED_DIR = os.path.join(PUBLIC_DIR, "enhanced_images")
os.makedirs(GENERATED_DIR, exist_ok=True)
os.makedirs(ENHANCED_DIR, exist_ok=True)

# === Load models ===
device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
pipe = StableDiffusionPipeline.from_pretrained("runwayml/stable-diffusion-v1-5").to(device)
gan = RealESRGAN(device, scale=4)
gan.load_weights("RealESRGAN_x4plus.pth")

# === Core function ===
def generate_and_enhance(prompt):
    image = pipe(prompt, num_inference_steps=50).images[0]
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    filename = f"{prompt.replace(' ', '_')[:30]}_{timestamp}.png"

    gen_path = os.path.join(GENERATED_DIR, filename)
    image.save(gen_path)

    # Super-resolution
    sr_image = gan.predict(image.convert("RGB"))
    enh_path = os.path.join(ENHANCED_DIR, filename)
    sr_image.save(enh_path)

    return enh_path

if __name__ == "__main__":
    # Generate and enhance the image
    enhanced_image_path = generate_and_enhance(args.prompt)
    
    # Print the path to the enhanced image (this will be captured by the Node.js exec function)
    print(enhanced_image_path)
