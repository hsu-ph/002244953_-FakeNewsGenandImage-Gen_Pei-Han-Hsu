"use client"

import { Button } from "@/components/ui/button"
import { ArrowRight, Palette, Sparkles, Zap } from "lucide-react"
import Image from "next/image"

export function WelcomePage({ onGetStarted }: { onGetStarted: () => void }) {
  return (
    <div className="min-h-screen flex flex-col">
      {/* Hero Section with Van Gogh-inspired background */}
      <div className="relative bg-gradient-to-br from-amber-900 via-red-800 to-rose-900 text-white overflow-hidden">
        {/* Swirly background pattern inspired by Starry Night */}
        <div className="absolute inset-0 opacity-20">
          <Image src="/starry-abstraction.png" alt="Van Gogh inspired pattern" fill className="object-cover" />
        </div>

        <div className="container mx-auto px-6 py-16 relative z-10">
          <div className="flex flex-col md:flex-row items-center justify-between gap-8">
            <div className="md:w-3/5">
              <h1 className="text-4xl md:text-5xl font-bold mb-4 leading-tight">
                <span className="text-amber-300">Vincent van Gogh</span> Reimagined Through AI
              </h1>
              <p className="text-xl mb-8 leading-relaxed">
                Explore the artistic universe of Vincent van Gogh, generating vivid, style-driven imagery based on
                prompts such as{" "}
                <span className="italic text-amber-200">"Van Gogh eating a hamburger in a modern café"</span> or{" "}
                <span className="italic text-amber-200">"A cyberpunk cityscape in Van Gogh's brushstrokes."</span>
              </p>
              <Button
                onClick={onGetStarted}
                size="lg"
                className="bg-amber-500 hover:bg-yellow-600 text-black font-medium"
              >
                Get Started <ArrowRight className="ml-2 h-4 w-4" />
              </Button>
            </div>

            <div className="md:w-2/5 relative">
              <div className="aspect-square max-w-md mx-auto relative rounded-lg overflow-hidden border-4 text-amber-300 shadow-2xl transform rotate-2">
                <Image
                  src="/images/vangogh_burger_1.png"
                  alt="Van Gogh eating a burger"
                  fill
                  className="object-cover"
                />
              </div>
              <div className="absolute -bottom-4 -left-4 bg-amber-500 text-black p-2 rounded-lg shadow-lg transform -rotate-3">
                <Sparkles className="h-5 w-5" />
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Features Section */}
      <div className="bg-gradient-to-r from-amber-50 to-rose-50 py-16">
        <div className="container mx-auto px-6">
          <h2 className="text-3xl font-bold text-center mb-12 text-blue-900">How It Works</h2>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            <div className="bg-white p-8 rounded-xl shadow-lg border border-amber-200 transform transition-transform hover:scale-105">
              <div className="flex items-center mb-4">
                <div className="bg-amber-100 p-3 rounded-full mr-4">
                  <Palette className="h-6 w-6 text-amber-700" />
                </div>
                <h3 className="text-xl font-semibold text-amber-900">Toggle Between Models</h3>
              </div>
              <p className="text-gray-700">
                The system allows users to toggle between{" "}
                <span className="font-medium text-red-600">non-fine-tuned</span> (general-purpose) and{" "}
                <span className="font-medium text-red-600">fine-tuned</span> versions of the diffusion model. This
                flexibility reveals the contrast between generic and style-specific generations—highlighting the
                potential of targeted fine-tuning in creative workflows.
              </p>
            </div>

            <div className="bg-white p-8 rounded-xl shadow-lg border border-amber-200 transform transition-transform hover:scale-105">
              <div className="flex items-center mb-4">
                <div className="bg-rose-100 p-3 rounded-full mr-4">
                  <Zap className="h-6 w-6 text-rose-700" />
                </div>
                <h3 className="text-xl font-semibold text-rose-900">Extensible Design</h3>
              </div>
              <p className="text-gray-700">
                Modular by design and extensible in function, this pipeline serves as a foundation for personalized
                AI-driven creativity across domains like digital art, education, media, and human-AI co-creation.
              </p>
            </div>
          </div>
        </div>
      </div>

      {/* Author Section */}
      <div className="bg-amber-900 text-white py-10">
        <div className="container mx-auto px-6 text-center">
          <p className="text-lg font-light">Created by</p>
          <h3 className="text-2xl font-bold mb-2">Pei-Han Hsu</h3>
          <p className="text-amber-300 max-w-2xl mx-auto">
            Exploring the intersection of artificial intelligence and artistic expression through innovative
            text-to-image generation techniques.
          </p>
        </div>
      </div>
    </div>
  )
}
