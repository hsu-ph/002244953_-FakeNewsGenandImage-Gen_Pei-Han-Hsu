"use client"

import { useState } from "react"
import { Loader2, AlertTriangle, CheckCircle, Info } from "lucide-react"

export function DatasetAAnalyzer() {
  const [newsTitle, setNewsTitle] = useState("")
  const [newsContent, setNewsContent] = useState("")
  const [loading, setLoading] = useState(false)
  const [result, setResult] = useState<{ prediction: string; confidence: number } | null>(null)
  const [showExplanation, setShowExplanation] = useState(false)
  const [threshold, setThreshold] = useState(0.7)
  const [detailedAnalysis, setDetailedAnalysis] = useState(false)

  // Sample fake news indicators
  const fakeNewsIndicators = [
    "Sensationalist language",
    "Lack of sources",
    "Emotional appeals",
    "Excessive punctuation",
    "Conspiracy theories",
    "Unverifiable claims",
  ]

  // Sample real news indicators
  const realNewsIndicators = [
    "Cited sources",
    "Balanced reporting",
    "Factual language",
    "Multiple perspectives",
    "Expert quotes",
    "Verifiable information",
  ]

  const analyzeNews = async () => {
    if (!newsTitle.trim() || !newsContent.trim()) {
      return
    }

    setLoading(true)
    setResult(null)

    try {
      // Simulate API call delay
      await new Promise((resolve) => setTimeout(resolve, 2000))

      // Simulate analysis result
      // In a real implementation, this would call an API that uses the FakeRealNewsDataset
      const isFake =
        newsTitle.toLowerCase().includes("shocking") ||
        newsTitle.toLowerCase().includes("you won't believe") ||
        newsContent.toLowerCase().includes("conspiracy") ||
        newsContent.toLowerCase().includes("they don't want you to know")

      const confidence = isFake ? 0.7 + Math.random() * 0.25 : 0.6 + Math.random() * 0.35

      setResult({
        prediction: confidence > threshold ? (isFake ? "FAKE" : "REAL") : "UNCERTAIN",
        confidence,
      })
    } catch (error) {
      console.error("Error analyzing news:", error)
    } finally {
      setLoading(false)
    }
  }

  const getResultColor = () => {
    if (!result) return ""
    if (result.prediction === "FAKE") return "text-red-600"
    if (result.prediction === "REAL") return "text-green-600"
    return "text-amber-600"
  }

  const getResultIcon = () => {
    if (!result) return null
    if (result.prediction === "FAKE") return <AlertTriangle className="h-6 w-6 text-red-600" />
    if (result.prediction === "REAL") return <CheckCircle className="h-6 w-6 text-green-600" />
    return <Info className="h-6 w-6 text-amber-600" />
  }

  const getIndicators = () => {
    if (!result) return []

    // Select a random subset of indicators based on the prediction
    const allIndicators = result.prediction === "FAKE" ? fakeNewsIndicators : realNewsIndicators
    const numIndicators = Math.floor(Math.random() * 3) + 2 // 2-4 indicators

    return allIndicators
      .sort(() => 0.5 - Math.random())
      .slice(0, numIndicators)
      .map((indicator) => ({
        name: indicator,
        confidence: (0.6 + Math.random() * 0.35).toFixed(2),
      }))
  }

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
      {/* Input Form */}
      <div className="space-y-6 border border-gray-200 p-6">
        <h2 className="text-2xl font-serif text-gray-800">Fake News Analyzer</h2>
        <p className="text-gray-600">Enter a news title and content to analyze its authenticity</p>

        <div className="space-y-4">
          <label htmlFor="news-title" className="block text-gray-700">
            News Title
          </label>
          <textarea
            id="news-title"
            placeholder="Enter the news headline or title"
            value={newsTitle}
            onChange={(e) => setNewsTitle(e.target.value)}
            className="w-full p-3 border border-gray-200 text-gray-800 focus:border-blue-600 focus:ring-0 outline-none"
          />
        </div>

        <div className="space-y-4">
          <label htmlFor="news-content" className="block text-gray-700">
            News Content
          </label>
          <textarea
            id="news-content"
            placeholder="Enter the news article content"
            value={newsContent}
            onChange={(e) => setNewsContent(e.target.value)}
            className="w-full min-h-[150px] p-3 border border-gray-200 text-gray-800 focus:border-blue-600 focus:ring-0 outline-none"
          />
        </div>

        <div className="space-y-2 pt-2">
          <div className="flex justify-between">
            <label htmlFor="threshold" className="text-gray-700">
              Confidence Threshold: {threshold.toFixed(2)}
            </label>
          </div>
          <input
            id="threshold"
            type="range"
            min={0.5}
            max={0.95}
            step={0.01}
            value={threshold}
            onChange={(e) => setThreshold(Number.parseFloat(e.target.value))}
            className="w-full h-2 bg-gray-200 rounded-lg appearance-none cursor-pointer"
          />
          <p className="text-xs text-gray-600">Higher values require stronger evidence for classification</p>
        </div>

        <div className="flex items-center space-x-2 pt-2">
          <input
            type="checkbox"
            id="detailed-analysis"
            checked={detailedAnalysis}
            onChange={(e) => setDetailedAnalysis(e.target.checked)}
            className="w-4 h-4 text-blue-600 border-gray-300 focus:ring-blue-500"
          />
          <label htmlFor="detailed-analysis" className="font-medium text-gray-800">
            Show Detailed Analysis
          </label>
        </div>

        <button
          className="w-full py-3 px-6 bg-blue-600 text-white hover:bg-blue-700 transition-colors"
          onClick={analyzeNews}
          disabled={loading || !newsTitle.trim() || !newsContent.trim()}
        >
          {loading ? (
            <>
              <Loader2 className="inline-block mr-2 h-4 w-4 animate-spin" />
              Analyzing...
            </>
          ) : (
            "Analyze News"
          )}
        </button>
      </div>

      {/* Results Display */}
      <div className="space-y-6 border border-gray-200 p-6">
        <h2 className="text-2xl font-serif text-gray-800">Analysis Results</h2>
        <p className="text-gray-600">Powered by Dataset A: Fake/Real News Classification</p>

        {loading ? (
          <div className="flex flex-col items-center justify-center h-[300px]">
            <Loader2 className="h-12 w-12 animate-spin text-blue-600 mb-4" />
            <p className="text-gray-700">Analyzing news content...</p>
          </div>
        ) : result ? (
          <div className="space-y-6">
            <div className="flex flex-col items-center justify-center p-6 border border-gray-200 rounded-lg bg-gray-50">
              <div className="flex items-center mb-4">
                {getResultIcon()}
                <h3 className={`text-2xl font-bold ml-2 ${getResultColor()}`}>{result.prediction}</h3>
              </div>
              <div className="w-full bg-gray-200 rounded-full h-2.5 mb-2">
                <div
                  className={`h-2.5 rounded-full ${
                    result.prediction === "FAKE"
                      ? "bg-red-600"
                      : result.prediction === "REAL"
                        ? "bg-green-600"
                        : "bg-amber-600"
                  }`}
                  style={{ width: `${result.confidence * 100}%` }}
                ></div>
              </div>
              <p className="text-sm text-gray-600">Confidence: {(result.confidence * 100).toFixed(1)}%</p>
            </div>

            {detailedAnalysis && (
              <div className="space-y-4">
                <h3 className="font-medium text-gray-800">Key Indicators:</h3>
                <ul className="space-y-2">
                  {getIndicators().map((indicator, index) => (
                    <li key={index} className="flex justify-between items-center p-2 border-b border-gray-100">
                      <span className="text-gray-700">{indicator.name}</span>
                      <span className="text-gray-800 font-medium">
                        {(Number.parseFloat(indicator.confidence) * 100).toFixed(0)}%
                      </span>
                    </li>
                  ))}
                </ul>
              </div>
            )}

            <div>
              <button
                className="w-full py-2 px-4 border border-gray-200 text-gray-700 hover:bg-gray-50"
                onClick={() => setShowExplanation(!showExplanation)}
              >
                {showExplanation ? "Hide Explanation" : "Show Explanation"}
              </button>

              {showExplanation && (
                <div className="mt-4 p-4 bg-gray-50 border border-gray-200 text-sm text-gray-700">
                  <p className="mb-2">
                    <strong>How this works:</strong>
                  </p>
                  <p>
                    This analyzer uses a machine learning model trained on Dataset A, which contains labeled examples of
                    fake and real news articles. The model analyzes patterns in the text, including:
                  </p>
                  <ul className="list-disc pl-5 mt-2 space-y-1">
                    <li>Language patterns and word choice</li>
                    <li>Emotional content and sensationalism</li>
                    <li>Structural elements typical of fake/real news</li>
                    <li>Contextual inconsistencies</li>
                  </ul>
                  <p className="mt-2">The confidence score indicates how certain the model is about its prediction.</p>
                </div>
              )}
            </div>
          </div>
        ) : (
          <div className="flex flex-col items-center justify-center h-[300px] text-center">
            <Info className="h-12 w-12 text-gray-400 mb-4 opacity-50" />
            <p className="text-gray-700">Enter a news title and content to analyze</p>
            <p className="text-gray-600 text-sm mt-2">
              The analyzer will evaluate the likelihood of the news being fake or real
            </p>
          </div>
        )}
      </div>
    </div>
  )
}
