import Image from "next/image"

interface QuoteDisplayProps {
  quote: string
  author: string
  image: string
}

export function QuoteDisplay({ quote, author, image }: QuoteDisplayProps) {
  return (
    <div className="grid grid-cols-1 md:grid-cols-2 gap-4 rounded-lg overflow-hidden">
      <div className="flex flex-col justify-center p-8 bg-muted/30">
        <blockquote className="text-3xl font-serif leading-relaxed">"{quote}"</blockquote>
        <cite className="mt-4 text-muted-foreground">— {author}</cite>
      </div>
      <div className="relative h-[400px]">
        <Image src={image || "/placeholder.svg"} alt={`Quote by ${author}`} fill className="object-cover" />
      </div>
    </div>
  )
}
