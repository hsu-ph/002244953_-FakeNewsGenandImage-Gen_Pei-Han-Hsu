import Image from "next/image"
import Link from "next/link"

interface PostCardProps {
  title: string
  description: string
  date: string
  readTime: string
  image: string
  href: string
}

export function PostCard({ title, description, date, readTime, image, href }: PostCardProps) {
  return (
    <div className="grid grid-cols-1 md:grid-cols-2 gap-8 items-start">
      <Link href={href} className="block relative aspect-video overflow-hidden">
        <Image
          src={image || "/placeholder.svg"}
          alt={title}
          width={600}
          height={400}
          className="object-cover w-full h-full"
        />
      </Link>
      <div className="space-y-4">
        <div className="flex items-center gap-2 text-sm text-gray-500">
          <time dateTime={date}>{date}</time>
          <span>•</span>
          <span>{readTime}</span>
        </div>
        <Link href={href}>
          <h3 className="text-2xl font-serif text-gray-800 hover:text-orange-600 transition-colors">{title}</h3>
        </Link>
        <p className="text-gray-600">{description}</p>
        <Link href={href} className="inline-block text-orange-600 hover:underline">
          Read more
        </Link>
      </div>
    </div>
  )
}
