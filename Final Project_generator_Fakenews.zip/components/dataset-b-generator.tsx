"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Textarea } from "@/components/ui/textarea"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Loader2, Copy, Info, RefreshCw } from "lucide-react"
import { Label } from "@/components/ui/label"
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group"
import { Slider } from "@/components/ui/slider"
import { Switch } from "@/components/ui/switch"

// Add these constants at the top of the file, right after the imports
const US = "<US>"
const UK = "<UK>"

export function DatasetBGenerator() {
  const [headline, setHeadline] = useState("")
  const [loading, setLoading] = useState(false)
  const [generatedArticle, setGeneratedArticle] = useState("")
  const [sourceStyle, setSourceStyle] = useState("cnn")
  const [articleLength, setArticleLength] = useState([500])
  const [includeQuotes, setIncludeQuotes] = useState(true)
  const [copiedToClipboard, setCopiedToClipboard] = useState(false)

  // Sample CNN headlines
  const cnnHeadlines = [
    "Senate passes bipartisan infrastructure bill after months of negotiations",
    "Tech giants face scrutiny as lawmakers debate new regulations",
    "Climate scientists warn of increasing extreme weather events",
    "Global supply chain issues continue to impact retail prices",
    "Healthcare workers describe challenges amid ongoing pandemic",
  ]

  // Sample Daily Mail headlines
  const dailyMailHeadlines = [
    "Royal family attends annual charity gala amid ongoing speculation",
    "Celebrity chef reveals secret to perfect Sunday roast",
    "Holiday travel chaos as transport workers announce strike action",
    "Property market sees unexpected surge in rural home purchases",
    "Football star signs record-breaking deal with Premier League club",
  ]

  const generateArticle = async () => {
    if (!headline.trim()) {
      return
    }

    setLoading(true)
    setGeneratedArticle("")
    setCopiedToClipboard(false)

    try {
      // Simulate API call delay
      await new Promise((resolve) => setTimeout(resolve, 2500))

      // Simulate article generation
      // In a real implementation, this would call an API that uses the CNNDailyMailDataset
      const paragraphs = generateParagraphs(headline, sourceStyle, Math.floor(articleLength[0] / 100), includeQuotes)
      setGeneratedArticle(paragraphs.join("\n\n"))
    } catch (error) {
      console.error("Error generating article:", error)
    } finally {
      setLoading(false)
    }
  }

  const generateParagraphs = (headline: string, source: string, numParagraphs: number, includeQuotes: boolean) => {
    const paragraphs = []
    const words = headline.split(" ")
    const isCNN = source === "cnn"

    // First paragraph - introduction
    if (isCNN) {
      paragraphs.push(
        `(CNN) -- ${headline}. The development comes as ${words[Math.floor(Math.random() * words.length)]} continues to be a focal point for many Americans across the country.`,
      )
    } else {
      paragraphs.push(
        `${headline.toUpperCase()}. The ${words[Math.floor(Math.random() * words.length)]} has sparked widespread reaction as details continue to emerge about the situation.`,
      )
    }

    // Middle paragraphs
    for (let i = 0; i < numParagraphs - 2; i++) {
      if (includeQuotes && i === 1) {
        // Add a quote paragraph
        const person = isCNN
          ? ["Senator John Smith", "Dr. Emily Chen", "White House spokesperson", "Industry analyst Mark Johnson"][
              Math.floor(Math.random() * 4)
            ]
          : ["Royal insider", "Source close to the family", "Celebrity expert", "Sports commentator"][
              Math.floor(Math.random() * 4)
            ]

        paragraphs.push(
          `"This is a significant development that will have far-reaching implications," said ${person}. "We're closely monitoring the situation as it unfolds and preparing for various scenarios."`,
        )
      } else {
        // Regular paragraph
        const randomWord = words[Math.floor(Math.random() * words.length)]
        const sentenceCount = 2 + Math.floor(Math.random() * 3)
        let paragraph = ""

        for (let j = 0; j < sentenceCount; j++) {
          if (isCNN) {
            paragraph += `The impact of ${randomWord} has been substantial according to experts. `
          } else {
            paragraph += `Insiders revealed that the ${randomWord} has caused quite a stir. `
          }
        }

        paragraphs.push(paragraph.trim())
      }
    }

    // Last paragraph - conclusion
    if (isCNN) {
      paragraphs.push(`As this story develops, CNN will continue to provide updates on the latest developments.`)
    } else {
      paragraphs.push(`More updates to follow as this story continues to develop.`)
    }

    return paragraphs
  }

  const getSampleHeadlines = () => {
    return sourceStyle === "cnn" ? cnnHeadlines : dailyMailHeadlines
  }

  const copyToClipboard = () => {
    navigator.clipboard.writeText(generatedArticle)
    setCopiedToClipboard(true)
    setTimeout(() => setCopiedToClipboard(false), 2000)
  }

  const getRandomHeadline = () => {
    const headlines = getSampleHeadlines()
    const randomIndex = Math.floor(Math.random() * headlines.length)
    setHeadline(headlines[randomIndex])
  }

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
      {/* Input Form */}
      <Card className="border-amber-200 shadow-lg">
        <CardHeader className="bg-gradient-to-r from-amber-50 to-rose-50 border-b border-amber-100">
          <CardTitle className="text-amber-800">News Article Generator</CardTitle>
          <CardDescription>Generate a news article based on a headline in CNN or Daily Mail style</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4 pt-6">
          <div className="space-y-2">
            <div className="flex justify-between items-center">
              <Label htmlFor="headline" className="text-amber-700">
                Headline
              </Label>
              <Button
                variant="ghost"
                size="sm"
                onClick={getRandomHeadline}
                className="h-8 text-amber-600 hover:text-amber-800 hover:bg-amber-100"
              >
                <RefreshCw className="h-3.5 w-3.5 mr-1" />
                Random
              </Button>
            </div>
            <Textarea
              id="headline"
              placeholder="Enter a news headline"
              value={headline}
              onChange={(e) => setHeadline(e.target.value)}
              className="border-amber-200 focus-visible:ring-amber-500"
            />
          </div>

          <div className="space-y-2">
            <Label className="text-amber-700">Source Style</Label>
            <RadioGroup value={sourceStyle} onValueChange={setSourceStyle} className="flex space-x-4">
              <div className="flex items-center space-x-2">
                <RadioGroupItem value="cnn" id="cnn" className="text-amber-600" />
                <Label htmlFor="cnn" className="font-normal">
                  CNN (US Style)
                </Label>
              </div>
              <div className="flex items-center space-x-2">
                <RadioGroupItem value="dailymail" id="dailymail" className="text-amber-600" />
                <Label htmlFor="dailymail" className="font-normal">
                  Daily Mail (UK Style)
                </Label>
              </div>
            </RadioGroup>
          </div>

          <div className="space-y-2 pt-2">
            <div className="flex justify-between">
              <Label htmlFor="article-length" className="text-amber-700">
                Article Length: ~{articleLength[0]} words
              </Label>
            </div>
            <Slider
              id="article-length"
              min={200}
              max={1000}
              step={100}
              value={articleLength}
              onValueChange={setArticleLength}
              className="[&>span]:bg-amber-600"
            />
          </div>

          <div className="flex items-center space-x-2 pt-2">
            <Switch
              id="include-quotes"
              checked={includeQuotes}
              onCheckedChange={setIncludeQuotes}
              className="data-[state=checked]:bg-amber-600"
            />
            <Label htmlFor="include-quotes" className="font-medium text-amber-800">
              Include Expert Quotes
            </Label>
          </div>
        </CardContent>
        <CardFooter className="bg-gradient-to-r from-amber-50 to-rose-50 border-t border-amber-100">
          <Button
            className="w-full bg-amber-600 hover:bg-amber-700"
            onClick={generateArticle}
            disabled={loading || !headline.trim()}
          >
            {loading ? (
              <>
                <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                Generating...
              </>
            ) : (
              "Generate Article"
            )}
          </Button>
        </CardFooter>
      </Card>

      {/* Output Display */}
      <Card className="border-amber-200 shadow-lg">
        <CardHeader className="bg-gradient-to-r from-amber-50 to-rose-50 border-b border-amber-100">
          <CardTitle className="text-amber-800">Generated Article</CardTitle>
          <CardDescription>Powered by Dataset B: CNN/Daily Mail News Articles</CardDescription>
        </CardHeader>
        <CardContent className="pt-6">
          {loading ? (
            <div className="flex flex-col items-center justify-center h-[400px]">
              <Loader2 className="h-12 w-12 animate-spin text-amber-600 mb-4" />
              <p className="text-amber-700">Generating article...</p>
            </div>
          ) : generatedArticle ? (
            <div className="space-y-4">
              <div className="border border-amber-200 rounded-lg p-4 bg-white max-h-[400px] overflow-y-auto">
                <h3 className="font-bold text-lg mb-4 text-amber-900">{headline}</h3>
                {generatedArticle.split("\n\n").map((paragraph, index) => (
                  <p key={index} className="mb-4 text-gray-700 last:mb-0">
                    {paragraph}
                  </p>
                ))}
              </div>

              <div className="flex justify-end">
                <Button
                  variant="outline"
                  size="sm"
                  className="border-amber-300 text-amber-700 hover:bg-amber-50"
                  onClick={copyToClipboard}
                >
                  <Copy className="h-4 w-4 mr-2" />
                  {copiedToClipboard ? "Copied!" : "Copy to Clipboard"}
                </Button>
              </div>

              <div className="p-4 bg-amber-50 border border-amber-200 rounded-lg text-sm text-amber-700">
                <p>
                  <strong>About this generation:</strong>
                </p>
                <p className="mt-1">
                  This article was generated in {sourceStyle.toUpperCase()} style using a model trained on Dataset B,
                  which contains thousands of news articles from CNN and Daily Mail. The model learns the writing style,
                  structure, and tone typical of each news source.
                </p>
              </div>
            </div>
          ) : (
            <div className="flex flex-col items-center justify-center h-[400px] text-center">
              <Info className="h-12 w-12 text-amber-400 mb-4 opacity-50" />
              <p className="text-amber-700">Enter a headline to generate an article</p>
              <p className="text-amber-600 text-sm mt-2">Choose between CNN (US) or Daily Mail (UK) writing styles</p>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  )
}
