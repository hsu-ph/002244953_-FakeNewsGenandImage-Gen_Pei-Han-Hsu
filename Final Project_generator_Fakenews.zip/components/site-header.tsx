"use client"

import Link from "next/link"
import { useLanguage } from "@/contexts/language-context"
import { LanguageSelector } from "@/components/language-selector"

export function SiteHeader() {
  const { t } = useLanguage()

  return (
    <header className="py-6">
      <div className="container mx-auto px-6 max-w-6xl">
        <div className="flex items-center justify-between">
          <Link href="/" className="text-3xl font-serif text-blue-600">
            Pei-Han Hsu
          </Link>
          <nav className="flex items-center space-x-6">
            <Link href="/generator" className="text-gray-600 hover:text-blue-600 transition-colors">
              {t("generator")}
            </Link>
            <Link href="/dataset-a" className="text-gray-600 hover:text-blue-600 transition-colors">
              {t("analyzer")}
            </Link>
            <LanguageSelector />
          </nav>
        </div>
      </div>
    </header>
  )
}
