"use client"

import type React from "react"
import { createContext, useContext, useState, useEffect } from "react"

type Language = {
  code: string
  name: string
  nativeName: string
}

export const languages: Language[] = [
  { code: "en", name: "English", nativeName: "English" },
  { code: "zh", name: "Chinese", nativeName: "中文" },
  { code: "ja", name: "Japanese", nativeName: "日本語" },
  { code: "ko", name: "Korean", nativeName: "한국어" },
]

type Translations = {
  [key: string]: {
    [key: string]: string
  }
}

// Basic translations for demonstration
export const translations: Translations = {
  en: {
    welcome: "Welcome to my portfolio",
    about: "About",
    intro: "I'm a researcher and developer specializing in AI and image generation.",
    generator: "Image Generator",
    analyzer: "News Analyzer",
    articleGen: "Article Generator",
    home: "Home",
    blog: "Blog",
    contact: "Contact",
    resources: "Resources",
    darkMode: "Dark Mode",
    lightMode: "Light Mode",
    generateBtn: "Generate Image",
    generating: "Generating...",
    prompt: "Prompt",
    promptPlaceholder: "A serene landscape with mountains and a lake at sunset",
    negativePrompt: "Negative Prompt (what to avoid)",
    negativePromptPlaceholder: "blurry, distorted, low quality",
    useFinetuned: "Use Fine-Tuned Model",
    advancedSettings: "Advanced Settings",
    inferenceSteps: "Inference Steps",
    guidanceScale: "Guidance Scale",
    seed: "Seed (optional)",
    seedPlaceholder: "Random seed for reproducibility",
    generatedImage: "Generated Image",
    downloadImage: "Download Image",
    downloadNote: "(Download functionality would be enabled in production)",
    simulationNotice: "Simulation Notice",
    simulationText:
      "This is a simulation of the image generation process. In a production environment, this would connect to your Python script to generate actual images.",
    getStarted: "Get Started",
    tryExample: "Try an example:",
    animalsCategory: "Animals/People",
    artCategory: "Art",
    foodCategory: "Food",
  },
  zh: {
    welcome: "歡迎來到我的作品集",
    about: "關於",
    intro: "我是一名專注於人工智能和圖像生成的研究人員和開發者。",
    generator: "圖像生成器",
    analyzer: "新聞分析器",
    articleGen: "文章生成器",
    home: "首頁",
    blog: "部落格",
    contact: "聯繫",
    resources: "資源",
    darkMode: "深色模式",
    lightMode: "淺色模式",
    generateBtn: "生成圖像",
    generating: "生成中...",
    prompt: "提示詞",
    promptPlaceholder: "一個寧靜的風景，有山脈和日落時的湖泊",
    negativePrompt: "負面提示詞（要避免的內容）",
    negativePromptPlaceholder: "模糊，扭曲，低質量",
    useFinetuned: "使用微調模型",
    advancedSettings: "高級設置",
    inferenceSteps: "推理步驟",
    guidanceScale: "引導比例",
    seed: "種子（可選）",
    seedPlaceholder: "用於可重現性的隨機種子",
    generatedImage: "生成的圖像",
    downloadImage: "下載圖像",
    downloadNote: "（下載功能將在生產環境中啟用）",
    simulationNotice: "模擬通知",
    simulationText: "這是圖像生成過程的模擬。在生產環境中，這將連接到您的Python腳本以生成實際圖像。",
    getStarted: "開始使用",
    tryExample: "嘗試一個例子：",
    animalsCategory: "動物/人物",
    artCategory: "藝術",
    foodCategory: "食物",
  },
  ja: {
    welcome: "ポートフォリオへようこそ",
    about: "私について",
    intro: "AIと画像生成を専門とする研究者・開発者です。",
    generator: "画像ジェネレーター",
    analyzer: "ニュース分析ツール",
    articleGen: "記事ジェネレーター",
    home: "ホーム",
    blog: "ブログ",
    contact: "お問い合わせ",
    resources: "リソース",
    darkMode: "ダークモード",
    lightMode: "ライトモード",
    generateBtn: "画像を生成",
    generating: "生成中...",
    prompt: "プロンプト",
    promptPlaceholder: "山と湖のある夕暮れの静かな風景",
    negativePrompt: "ネガティブプロンプト（避けたいもの）",
    negativePromptPlaceholder: "ぼやけた、歪んだ、低品質",
    useFinetuned: "微調整モデルを使用",
    advancedSettings: "詳細設定",
    inferenceSteps: "推論ステップ",
    guidanceScale: "ガイダンススケール",
    seed: "シード（オプション）",
    seedPlaceholder: "再現性のためのランダムシード",
    generatedImage: "生成された画像",
    downloadImage: "画像をダウンロード",
    downloadNote: "（ダウンロード機能は本番環境で有効になります）",
    simulationNotice: "シミュレーション通知",
    simulationText:
      "これは画像生成プロセスのシミュレーションです。本番環境では、実際の画像を生成するためにPythonスクリプトに接続されます。",
    getStarted: "始めましょう",
    tryExample: "例を試してみる：",
    animalsCategory: "動物/人",
    artCategory: "アート",
    foodCategory: "食べ物",
  },
  ko: {
    welcome: "내 포트폴리오에 오신 것을 환영합니다",
    about: "나에 대해",
    intro: "AI 및 이미지 생성을 전문으로 하는 연구원이자 개발자입니다.",
    generator: "이미지 생성기",
    analyzer: "뉴스 분석기",
    articleGen: "기사 생성기",
    home: "홈",
    blog: "블로그",
    contact: "연락처",
    resources: "리소스",
    darkMode: "다크 모드",
    lightMode: "라이트 모드",
    generateBtn: "이미지 생성",
    generating: "생성 중...",
    prompt: "프롬프트",
    promptPlaceholder: "산과 호수가 있는 일몰 시간의 고요한 풍경",
    negativePrompt: "네거티브 프롬프트 (피해야 할 것)",
    negativePromptPlaceholder: "흐릿함, 왜곡, 낮은 품질",
    useFinetuned: "미세 조정된 모델 사용",
    advancedSettings: "고급 설정",
    inferenceSteps: "추론 단계",
    guidanceScale: "가이던스 스케일",
    seed: "시드 (선택 사항)",
    seedPlaceholder: "재현성을 위한 랜덤 시드",
    generatedImage: "생성된 이미지",
    downloadImage: "이미지 다운로드",
    downloadNote: "(다운로드 기능은 프로덕션 환경에서 활성화됩니다)",
    simulationNotice: "시뮬레이션 알림",
    simulationText:
      "이것은 이미지 생성 프로세스의 시뮬레이션입니다. 프로덕션 환경에서는 실제 이미지를 생성하기 위해 Python 스크립트에 연결됩니다.",
    getStarted: "시작하기",
    tryExample: "예시 사용해보기:",
    animalsCategory: "동물/인물",
    artCategory: "예술",
    foodCategory: "음식",
  },
}

type LanguageContextType = {
  language: Language
  setLanguage: (language: Language) => void
  t: (key: string) => string
}

const LanguageContext = createContext<LanguageContextType | undefined>(undefined)

export function LanguageProvider({ children }: { children: React.ReactNode }) {
  const [language, setLanguage] = useState<Language>(languages[0])

  // Persist language preference
  useEffect(() => {
    const savedLanguage = localStorage.getItem("language")
    if (savedLanguage) {
      const lang = languages.find((l) => l.code === savedLanguage)
      if (lang) setLanguage(lang)
    }
  }, [])

  useEffect(() => {
    localStorage.setItem("language", language.code)
    document.documentElement.lang = language.code
  }, [language])

  // Translation function
  const t = (key: string): string => {
    return translations[language.code]?.[key] || translations.en[key] || key
  }

  return <LanguageContext.Provider value={{ language, setLanguage, t }}>{children}</LanguageContext.Provider>
}

export function useLanguage() {
  const context = useContext(LanguageContext)
  if (context === undefined) {
    throw new Error("useLanguage must be used within a LanguageProvider")
  }
  return context
}
