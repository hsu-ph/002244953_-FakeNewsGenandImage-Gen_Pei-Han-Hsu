"use client"

import { DatasetAAnalyzer } from "@/components/dataset-a-analyzer"
import { useLanguage } from "@/contexts/language-context"

export default function DatasetAPage() {
  const { t } = useLanguage()

  return (
    <div className="bg-white">
      <div className="container mx-auto px-6 max-w-6xl py-12">
        <div className="mb-12">
          <h1 className="text-4xl font-serif mb-4 text-gray-800">{t("analyzer")}</h1>
          <p className="text-xl text-gray-600 max-w-2xl">Analyze news content to determine its authenticity using AI</p>
        </div>

        <DatasetAAnalyzer />
      </div>
    </div>
  )
}
