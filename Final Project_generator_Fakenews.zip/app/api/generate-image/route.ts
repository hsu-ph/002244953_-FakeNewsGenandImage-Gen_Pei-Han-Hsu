import { NextResponse } from "next/server"
import { exec } from "child_process"
import { promisify } from "util"
import path from "path"
import fs from "fs/promises"

const execAsync = promisify(exec)

export async function POST(request: Request) {
  try {
    const { prompt } = await request.json()

    if (!prompt || typeof prompt !== "string") {
      return NextResponse.json({ error: "Invalid prompt" }, { status: 400 })
    }

    // Path to the Python script
    const scriptPath = path.join(process.cwd(), "generate_web_app.py")

    // Execute the Python script with the prompt
    // We're modifying the script execution to accept a prompt as an argument
    // and return the path to the generated image
    const { stdout, stderr } = await execAsync(`python ${scriptPath} --prompt "${prompt}"`)

    if (stderr) {
      console.error("Python script error:", stderr)
      return NextResponse.json({ error: "Error executing the Python script" }, { status: 500 })
    }

    // The Python script should output the path to the enhanced image
    // We'll need to modify the Python script to accept command line arguments
    // and return the path to the generated image
    const imagePath = stdout.trim()

    // Check if the image exists
    try {
      await fs.access(imagePath)
    } catch (error) {
      return NextResponse.json({ error: "Generated image not found" }, { status: 500 })
    }

    // Get the filename from the path
    const filename = path.basename(imagePath)

    // Return the URL to the enhanced image
    // Assuming the enhanced images are saved in a public directory
    return NextResponse.json({ imageUrl: `/enhanced_images/${filename}` })
  } catch (error) {
    console.error("Error generating image:", error)
    return NextResponse.json({ error: "Failed to generate image" }, { status: 500 })
  }
}
