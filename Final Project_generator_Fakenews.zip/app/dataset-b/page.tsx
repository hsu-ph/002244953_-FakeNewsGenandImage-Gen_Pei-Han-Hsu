"use client"

import { SiteHeader } from "@/components/site-header"
import { DatasetBGenerator } from "@/components/dataset-b-generator"

export default function DatasetBPage() {
  return (
    <div className="min-h-screen bg-background text-foreground">
      <SiteHeader />

      <main className="container max-w-screen-xl py-12">
        <div className="mb-12 text-center">
          <h1 className="text-4xl font-serif mb-4">News Article Generator</h1>
          <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
            Generate news articles in different publication styles from simple headlines
          </p>
        </div>

        <DatasetBGenerator />
      </main>
    </div>
  )
}
