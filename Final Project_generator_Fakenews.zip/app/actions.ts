"use server"

import { exec } from "child_process"
import { promisify } from "util"
import fs from "fs/promises"
import path from "path"

const execAsync = promisify(exec)

export async function generateImage(prompt: string): Promise<{ imageUrl?: string; error?: string }> {
  try {
    // Create a unique filename based on timestamp
    const timestamp = Date.now()
    const outputFilename = `generated_image_${timestamp}.png`
    const outputPath = path.join(process.cwd(), "public", "generated", outputFilename)

    // Ensure the output directory exists
    await fs.mkdir(path.join(process.cwd(), "public", "generated"), { recursive: true })

    // Execute your Python script with the prompt
    // Replace 'your_script.py' with the actual path to your Python script
    const { stdout, stderr } = await execAsync(`python your_script.py "${prompt}" "${outputPath}"`)

    if (stderr) {
      console.error("Python script error:", stderr)
      return { error: "Error executing the Python script" }
    }

    // Return the URL to the generated image
    return { imageUrl: `/generated/${outputFilename}` }

    // For development/testing purposes, you can return a placeholder image
    // return { imageUrl: "/placeholder.svg?height=400&width=600" };
  } catch (error) {
    console.error("Error generating image:", error)
    return { error: "Failed to generate image. Please try again." }
  }
}
