"use client"

import { useState } from "react"
import { useLanguage } from "@/contexts/language-context"
import Image from "next/image"
import { Loader2, Info, Lightbulb } from "lucide-react"

// Define example categories and prompts
const exampleCategories = {
  animals: {
    prompts: [
      "A cute koala hugging a tree branch",
      "Penguins sharing an umbrella in the rain",
      "A colorful dragon with green scales and pink wings",
      "Llamas grazing on a hillside in Peru",
      "A panda eating bamboo in a forest",
      "A sloth making coffee in a kitchen",
      "A fox knight riding a wolf with an axe",
      "A man presenting a wildlife show with lions",
      "A frog sitting on a lily pad in a pond",
      "A flamingo walking with bright orange legs",
      "A cat wearing a chef hat in a kitchen",
      "A steampunk flying elephant with mechanical parts",
      "A detective in a dark coat and hat",
      "A raccoon in a small boat wearing a hat",
      "A corgi dog flying over a city",
      "An octopus underwater with tentacles spread out",
      "A green hummingbird flying through a cyberpunk city",
      "A penguin resting on an ice formation",
      "A sea turtle swimming with tropical fish",
      "Lily pads floating on a tranquil pond",
      "A fox exploring a magical cave with glowing orbs",
      "A man fishing by a lake with a small boat",
      "A dachshund dog on top of a hot dog cart",
      "An astronaut with a moon rabbit companion",
      "An owl with glasses formed from a tree with books",
      "Colorful jellyfish floating in deep blue water",
    ],
    images: [
      "/examples/animals/koala.png",
      "/examples/animals/penguins.png",
      "/examples/animals/dragon.png",
      "/examples/animals/llamas.png",
      "/examples/animals/panda.png",
      "/examples/animals/sloth.png",
      "/examples/animals/fox.png",
      "/examples/animals/lion.png",
      "/examples/animals/frog.png",
      "/examples/animals/flamingo.png",
      "/examples/animals/chef_cat.png",
      "/examples/animals/steampunk_elephant.png",
      "/examples/animals/detective.png",
      "/examples/animals/raccoon_boat.png",
      "/examples/animals/flying_corgi.png",
      "/examples/animals/octopus.png",
      "/examples/animals/cyberpunk_hummingbird.png",
      "/examples/animals/penguin_ice.png",
      "/examples/animals/sea_turtle.png",
      "/examples/animals/lily_pads.png",
      "/examples/animals/fox_cave.png",
      "/examples/animals/fishing_man.png",
      "/examples/animals/hotdog_dog.png",
      "/examples/animals/astronaut_rabbit.png",
      "/examples/animals/owl_tree.png",
      "/examples/animals/jellyfish.png",
    ],
  },
  art: {
    prompts: [
      "A cyberpunk scene with neon lights and computer screens",
      "A colorful dragon in digital art style",
      "A fantasy fox knight riding a wolf in storybook illustration style",
      "A DJ performing at a concert with purple lighting",
      "Van Gogh style painting of a starry night over a modern city",
      "Watercolor painting of a mountain landscape at sunset",
      "Japanese ukiyo-e style illustration of Tokyo skyline",
      "Pop art portrait of a woman with bright colors",
      "Abstract art with vibrant streaks of color",
      "A fantasy potion shop with shelves of magical bottles",
      "Pop art portraits in a modern art gallery",
      "Van Gogh's painting of a wooden chair with blue background",
      "A cartoon robot illustration with watercolor style",
      "Renaissance painting with figures in colorful robes",
      "Van Gogh self-portrait with a straw hat and hamburgers",
      "A cat dressed as royalty in a classical portrait style",
      "A hamburger painted in Van Gogh's impressionist style",
      "A framed landscape painting in a gold ornate frame",
      "Japanese sushi arranged artistically on a wooden table",
      "Milan Cathedral illuminated with fireworks at night",
      "A futuristic art installation with a glowing blue portal",
      "Colorful paper lanterns hanging from a ceiling",
      "Vibrant street art graffiti featuring an eye design",
      "Cartoon raccoons playing musical instruments in a moonlit forest",
      "Van Gogh painting himself with Starry Night in the background",
      "Ramen noodles arranged to look like The Great Wave",
      "Van Gogh style painting of a person walking through a sunflower field",
      "Vintage tea set display with porcelain cups and teapots",
      "Medieval-style illustration of a robot knight on horseback",
      "Van Gogh self-portrait with vibrant colors and blue background",
      "Van Gogh style painting of a night city with reflections on wet streets",
      "Van Gogh's painting of chairs with sunflowers in a room with yellow walls",
      "Close-up detail of Van Gogh's Starry Night with swirling stars",
      "Van Gogh self-portrait eating something yellow with starry background",
      "Van Gogh self-portrait with intense gaze and swirling blue background",
    ],
    images: [
      "/examples/art/cyberpunk.png",
      "/examples/animals/dragon.png",
      "/examples/animals/fox.png",
      "/examples/art/concert.png",
      "/images/vangogh_3_city_night.png",
      "/placeholder.svg?height=512&width=512&text=Watercolor+Mountain",
      "/placeholder.svg?height=512&width=512&text=Ukiyo-e+Tokyo",
      "/placeholder.svg?height=512&width=512&text=Pop+Art+Portrait",
      "/examples/art/abstract_colors.png",
      "/examples/fantasy/potion_shop.png",
      "/examples/art/pop_art_gallery.png",
      "/examples/art/vangogh_chair.png",
      "/examples/art/robot_illustration.png",
      "/examples/art/renaissance_painting.png",
      "/examples/art/vangogh_burger_portrait.png",
      "/examples/art/royal_cat_portrait.png",
      "/examples/art/vangogh_burger.png",
      "/examples/art/framed_landscape.png",
      "/examples/art/sushi_table.png",
      "/examples/art/milan_fireworks.png",
      "/examples/art/futuristic_portal.png",
      "/examples/art/colorful_lanterns.png",
      "/examples/art/street_art_eye.png",
      "/examples/art/raccoon_band.png",
      "/examples/art/vangogh_painting.png",
      "/examples/art/ramen_wave.png",
      "/examples/art/vangogh_sunflowers.png",
      "/examples/art/vintage_tea_set.png",
      "/examples/art/robot_knight.png",
      "/examples/art/vangogh_self_portrait.png",
      "/examples/art/vangogh_night_city.png",
      "/examples/art/vangogh_chairs_sunflowers.png",
      "/examples/art/vangogh_starry_night_detail.png",
      "/examples/art/vangogh_eating.png",
      "/examples/art/vangogh_portrait_swirls.png",
    ],
  },
  food: {
    prompts: [
      "A gourmet burger with melted cheese and fresh vegetables",
      "A colorful fruit platter with tropical fruits",
      "A steaming cup of coffee with latte art",
      "A traditional Japanese sushi platter",
      "A slice of chocolate cake with berries on top",
      "A rustic Italian pizza with fresh basil",
      "A stack of fluffy pancakes with maple syrup",
      "A bowl of ramen with steam rising",
      "A Japanese bento box with sushi, rice, and vegetables",
      "A tall white wedding cake decorated with fresh strawberries",
      "Colorful macarons floating in a cosmic purple space",
      "Ceramic bowls filled with vibrant colored liquids on a wooden table",
    ],
    images: [
      "/placeholder.svg?height=512&width=512&text=Gourmet+Burger",
      "/placeholder.svg?height=512&width=512&text=Fruit+Platter",
      "/placeholder.svg?height=512&width=512&text=Coffee+Latte+Art",
      "/placeholder.svg?height=512&width=512&text=Sushi+Platter",
      "/placeholder.svg?height=512&width=512&text=Chocolate+Cake",
      "/placeholder.svg?height=512&width=512&text=Italian+Pizza",
      "/placeholder.svg?height=512&width=512&text=Pancakes",
      "/placeholder.svg?height=512&width=512&text=Ramen+Bowl",
      "/examples/food/bento_box.png",
      "/examples/food/white_cake.png",
      "/examples/food/cosmic_macarons.png",
      "/examples/food/colorful_bowls.png",
    ],
  },
}

export default function GeneratorPage() {
  const { t } = useLanguage()

  // State for form inputs
  const [prompt, setPrompt] = useState("")
  const [negativePrompt, setNegativePrompt] = useState("")
  const [useFinetuning, setUseFinetuning] = useState(false)
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const [generatedImage, setGeneratedImage] = useState<string | null>(null)
  const [selectedCategory, setSelectedCategory] = useState<string | null>(null)

  // Collection of all Van Gogh images
  const vanGoghImages = [
    "/images/vangogh_burger_1.png",
    "/images/vangogh_burger_2.png",
    "/images/vangogh_burger_3.png",
    "/images/vangogh_burger_4.png",
    "/images/vangogh_chair_1.png",
    "/images/vangogh_chair_2.png",
  ]

  // Collection of all other images
  const otherImages = ["/images/milan_cathedral.png", "/images/renaissance_ufo.png", "/images/tokyo_tower.png"]

  // Collection of non-fine-tuned Van Gogh style images
  const nonFineTunedVanGoghImages = [
    "/images/vangogh_0_starry_night_alt.png",
    "/images/vangogh_1_noodles.png",
    "/images/vangogh_2_sunflower_field.png",
    "/images/vangogh_3_city_night.png",
    "/images/vangogh_4_burger.png",
    "/images/vangogh_5_sunflower_chair.png",
    "/images/vangogh_6_portrait.png",
    "/images/vangogh_7_portrait_desk.png",
    "/images/vangogh_8_starry_night.png",
  ]

  // Function to get a random image from an array
  const getRandomImage = (imageArray: string[]) => {
    const randomIndex = Math.floor(Math.random() * imageArray.length)
    return imageArray[randomIndex]
  }

  // Function to get a random image based on the prompt
  const getRandomImageForPrompt = (promptText: string) => {
    // Check if the prompt contains Van Gogh
    const isVanGoghPrompt =
      promptText.toLowerCase().includes("vangogh") || promptText.toLowerCase().includes("van gogh")

    if (isVanGoghPrompt) {
      // For Van Gogh prompts, use a random Van Gogh image when fine-tuning is enabled
      // or a random non-fine-tuned Van Gogh image when fine-tuning is disabled
      return useFinetuning ? getRandomImage(vanGoghImages) : getRandomImage(nonFineTunedVanGoghImages)
    }

    // For Milan Cathedral
    if (promptText.toLowerCase().includes("milan") || promptText.toLowerCase().includes("cathedral")) {
      return useFinetuning
        ? "/images/milan_cathedral.png"
        : `/placeholder.svg?height=512&width=512&text=${encodeURIComponent("Milan Cathedral")}`
    }

    // For Tokyo Tower
    if (
      promptText.toLowerCase().includes("tokyo") ||
      promptText.toLowerCase().includes("tower") ||
      promptText.toLowerCase().includes("cherry")
    ) {
      return useFinetuning
        ? "/images/tokyo_tower.png"
        : `/placeholder.svg?height=512&width=512&text=${encodeURIComponent("Tokyo Tower")}`
    }

    // For other prompts, use a random image or placeholder
    return useFinetuning
      ? getRandomImage([...vanGoghImages, ...otherImages])
      : `/placeholder.svg?height=512&width=512&text=${encodeURIComponent(`Standard: ${promptText}`)}`
  }

  // Function to handle category selection
  const handleCategorySelect = (category: string) => {
    setSelectedCategory(category)
    const categoryData = exampleCategories[category as keyof typeof exampleCategories]

    // Get random index
    const randomIndex = Math.floor(Math.random() * categoryData.prompts.length)

    // Set prompt to random example from category
    setPrompt(categoryData.prompts[randomIndex])

    // Set generated image to corresponding example image
    setGeneratedImage(categoryData.images[randomIndex])
  }

  // Function to simulate image generation
  const generateImage = async () => {
    if (!prompt.trim()) {
      setError("Please enter a prompt")
      return
    }

    setLoading(true)
    setError(null)

    try {
      // Simulate API call delay
      await new Promise((resolve) => setTimeout(resolve, 2000))

      // Get a random image based on the prompt and fine-tuning setting
      const imageUrl = getRandomImageForPrompt(prompt)

      setGeneratedImage(imageUrl)
    } catch (err) {
      console.error("Error:", err)
      setError(err instanceof Error ? err.message : "An error occurred while generating the image")
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="bg-white">
      <div className="container mx-auto px-6 max-w-6xl py-12">
        <div className="mb-12">
          <h1 className="text-4xl font-serif mb-4 text-gray-800">{t("generator")}</h1>
          <p className="text-xl text-gray-600 max-w-2xl">Generate images from text prompts with optional fine-tuning</p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-12">
          {/* Input Form */}
          <div className="space-y-8">
            {/* Suggestion Buttons */}
            <div className="space-y-4">
              <div className="flex items-center gap-2 mb-2">
                <Lightbulb className="h-5 w-5 text-blue-600" />
                <span className="text-gray-800 font-medium">Try an example:</span>
              </div>
              <div className="flex flex-wrap gap-3">
                <button
                  onClick={() => handleCategorySelect("animals")}
                  className={`px-4 py-2 border ${
                    selectedCategory === "animals"
                      ? "bg-blue-600 text-white border-blue-600"
                      : "border-gray-300 text-gray-700 hover:border-blue-600 hover:text-blue-600"
                  } transition-colors`}
                >
                  Animals/People
                </button>
                <button
                  onClick={() => handleCategorySelect("art")}
                  className={`px-4 py-2 border ${
                    selectedCategory === "art"
                      ? "bg-blue-600 text-white border-blue-600"
                      : "border-gray-300 text-gray-700 hover:border-blue-600 hover:text-blue-600"
                  } transition-colors`}
                >
                  Art
                </button>
                <button
                  onClick={() => handleCategorySelect("food")}
                  className={`px-4 py-2 border ${
                    selectedCategory === "food"
                      ? "bg-blue-600 text-white border-blue-600"
                      : "border-gray-300 text-gray-700 hover:border-blue-600 hover:text-blue-600"
                  } transition-colors`}
                >
                  Food
                </button>
              </div>
            </div>

            <div className="space-y-4">
              <label htmlFor="prompt" className="block text-lg text-gray-800">
                {t("prompt")}
              </label>
              <textarea
                id="prompt"
                placeholder={t("promptPlaceholder")}
                value={prompt}
                onChange={(e) => setPrompt(e.target.value)}
                className="w-full min-h-[120px] p-3 border border-gray-200 text-gray-800 focus:border-blue-600 focus:ring-0 outline-none"
              />
            </div>

            <div className="space-y-4">
              <label htmlFor="negative-prompt" className="block text-lg text-gray-800">
                {t("negativePrompt")}
              </label>
              <textarea
                id="negative-prompt"
                placeholder={t("negativePromptPlaceholder")}
                value={negativePrompt}
                onChange={(e) => setNegativePrompt(e.target.value)}
                className="w-full p-3 border border-gray-200 text-gray-800 focus:border-blue-600 focus:ring-0 outline-none"
              />
            </div>

            <div className="flex items-center space-x-3">
              <input
                type="checkbox"
                id="fine-tuning"
                checked={useFinetuning}
                onChange={(e) => setUseFinetuning(e.target.checked)}
                className="w-4 h-4 text-blue-600 border-gray-300 focus:ring-blue-500"
              />
              <label htmlFor="fine-tuning" className="text-gray-800">
                {t("useFinetuned")}
              </label>
            </div>

            <button
              className="w-full py-3 px-6 bg-blue-600 text-white hover:bg-blue-700 transition-colors"
              onClick={generateImage}
              disabled={loading || !prompt.trim()}
            >
              {loading ? (
                <>
                  <Loader2 className="inline-block mr-2 h-5 w-5 animate-spin" />
                  {t("generating")}
                </>
              ) : (
                t("generateBtn")
              )}
            </button>
          </div>

          {/* Output Display */}
          <div className="space-y-6">
            <div className="text-lg font-medium text-gray-800">{t("generatedImage")}</div>

            {error && <div className="w-full p-4 mb-4 bg-red-50 text-red-600 border border-red-100">{error}</div>}

            <div className="relative aspect-square border border-gray-200 flex items-center justify-center">
              {generatedImage ? (
                <Image
                  src={generatedImage || "/placeholder.svg"}
                  alt="AI generated image based on the prompt"
                  fill
                  className="object-contain"
                />
              ) : (
                <div className="text-gray-500 text-center p-4">
                  <Info className="h-12 w-12 mx-auto mb-2 opacity-50" />
                  <p>{t("generatedImage")}</p>
                </div>
              )}
            </div>

            {generatedImage && (
              <div className="w-full">
                <button className="w-full py-2 px-4 border border-gray-200 text-gray-600" disabled>
                  {t("downloadImage")}
                </button>
                <p className="text-xs text-center mt-2 text-gray-500">{t("downloadNote")}</p>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  )
}
