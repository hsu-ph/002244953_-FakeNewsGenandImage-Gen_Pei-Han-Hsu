"use client"

import Image from "next/image"
import Link from "next/link"
import { useLanguage } from "@/contexts/language-context"
import { ArrowRight } from "lucide-react"

export default function Home() {
  const { t } = useLanguage()

  return (
    <div className="min-h-screen bg-white flex flex-col">
      <main className="flex-grow flex items-center">
        <div className="container mx-auto px-6 max-w-6xl">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-12 items-center">
            {/* Photo and Name Section */}
            <div className="flex flex-col items-center md:items-start">
              <div className="relative w-64 h-64 md:w-80 md:h-80 mb-8 overflow-hidden">
                <Image
                  src="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/DSC06567.jpg-XEw224biyiUw67Xz0Haofm4TnEiRHs.jpeg"
                  alt="Pei-Han Hsu"
                  fill
                  className="object-cover rounded-lg"
                  priority
                />
              </div>
              <h1 className="text-4xl md:text-5xl font-serif text-blue-700 mb-2">Pei-Han Hsu</h1>
              <p className="text-xl text-gray-600 mb-8 text-center md:text-left max-w-xl">
                AI Research Scientist specializing in generative models and computer vision. With expertise in
                fine-tuning diffusion models and developing custom image generation pipelines, I focus on creating
                innovative solutions that bridge artistic expression and technical implementation.
              </p>
              <div className="flex flex-col sm:flex-row gap-4">
                <Link
                  href="/generator"
                  className="inline-flex items-center px-8 py-4 bg-blue-600 text-white hover:bg-blue-700 transition-colors"
                >
                  {t("getStarted")} <ArrowRight className="ml-2 h-5 w-5" />
                </Link>
                <Link
                  href="/dataset-a"
                  className="inline-flex items-center px-8 py-4 border border-blue-600 text-blue-600 hover:bg-blue-50 transition-colors"
                >
                  {t("analyzer")}
                </Link>
              </div>
            </div>

            {/* Quote Section */}
            <div className="hidden md:block">
              <div className="border-l-4 border-blue-600 pl-8 py-2">
                <blockquote className="text-2xl font-serif leading-relaxed text-gray-800">
                  "The intersection of art and technology offers unprecedented opportunities for creative expression and
                  innovation."
                </blockquote>
                <cite className="block text-gray-500 mt-4">— My Research Philosophy</cite>
              </div>
              <div className="mt-12 relative h-[300px] overflow-hidden rounded-lg">
                <Image
                  src="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/%E6%88%AA%E5%9C%96%202025-04-21%20%E4%B8%8B%E5%8D%887.04.19-J1kbn01IOjvWZN32JTe4PFqq0vpdUx.png"
                  alt="Artistic light through hand"
                  fill
                  className="object-cover"
                />
              </div>
            </div>
          </div>
        </div>
      </main>
    </div>
  )
}
